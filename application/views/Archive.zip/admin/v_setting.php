<?php
defined('BASEPATH') or exit('No direct script access allowed');
$this->load->view('_partials/header');
?>
<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1> Setting </h1>
        </div>

        <div class="section-body">
            <?php

            ?>
        </div>
    </section>
</div>
<?php $this->load->view('_partials/footer'); ?>